package com.cleaner.filemanager.util

import android.app.AppOpsManager
import android.app.usage.StorageStats
import android.app.usage.StorageStatsManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.os.Build
import android.os.Process

/**
 * Menghitung ukuran data aplikasi terinstall menggunakan StorageStatsManager —
 * API resmi Android untuk kasus ini.
 *
 * LATAR BELAKANG: sejak Android 11 (Scoped Storage), app pihak ketiga TIDAK bisa
 * membaca isi folder Android/data/<package_app_lain> secara langsung lewat
 * File.listFiles() biasa, meski sudah punya izin "All Files Access"
 * (MANAGE_EXTERNAL_STORAGE). Ini pembatasan keamanan resmi dari Google, bukan bug.
 *
 * Satu-satunya cara resmi untuk tetap mendapatkan ukuran data tiap app adalah lewat
 * StorageStatsManager.queryStatsForUid(), yang butuh izin "Usage Access"
 * (PACKAGE_USAGE_STATS) — izin terpisah dari "All Files Access", harus diaktifkan
 * manual oleh pengguna di Settings > Apps khusus > Akses penggunaan data.
 */
object AppDataSizeHelper {

    data class AppStorageInfo(
        val packageName: String,
        val appLabel: String,
        val appBytes: Long,      // ukuran APK terinstall
        val dataBytes: Long,     // ukuran folder data internal app (Android/data/<pkg>)
        val cacheBytes: Long     // ukuran cache internal app
    )

    /**
     * Cek apakah pengguna sudah memberi izin "Usage Access" untuk app ini.
     * Tanpa izin ini, queryStatsForUid akan selalu gagal/melempar SecurityException.
     */
    fun hasUsageAccessPermission(context: Context): Boolean {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            appOps.unsafeCheckOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                context.packageName
            )
        } else {
            @Suppress("DEPRECATION")
            appOps.checkOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                context.packageName
            )
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    /**
     * Hitung total ukuran data+cache dari semua app terinstall (selain app ini sendiri).
     * Mengembalikan null jika izin belum diberikan atau API tidak tersedia.
     */
    fun getTotalAppDataSize(context: Context): Pair<Long, List<AppStorageInfo>>? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return null
        if (!hasUsageAccessPermission(context)) return null

        val storageStatsManager = context.getSystemService(Context.STORAGE_STATS_SERVICE) as? StorageStatsManager
            ?: return null

        val packageManager = context.packageManager
        val installedApps: List<ApplicationInfo> = try {
            packageManager.getInstalledApplications(0)
        } catch (e: Exception) {
            return null
        }

        val results = mutableListOf<AppStorageInfo>()
        var totalBytes = 0L

        // Data aplikasi (Android/data) selalu berada di internal storage utama,
        // jadi cukup pakai UUID_DEFAULT (tidak perlu deteksi storage volume).
        val uuid = android.os.storage.StorageManager.UUID_DEFAULT

        for (appInfo in installedApps) {
            // Lewati aplikasi kita sendiri agar tidak menghitung diri sendiri sebagai "data lain"
            if (appInfo.packageName == context.packageName) continue

            try {
                val stats: StorageStats = storageStatsManager.queryStatsForUid(uuid, appInfo.uid)
                val appBytes = stats.appBytes
                val dataBytes = stats.dataBytes
                val cacheBytes = stats.cacheBytes

                val total = appBytes + dataBytes
                if (total <= 0L) continue

                val label = try {
                    packageManager.getApplicationLabel(appInfo).toString()
                } catch (e: Exception) {
                    appInfo.packageName
                }

                results.add(
                    AppStorageInfo(
                        packageName = appInfo.packageName,
                        appLabel = label,
                        appBytes = appBytes,
                        dataBytes = dataBytes,
                        cacheBytes = cacheBytes
                    )
                )
                totalBytes += total
            } catch (e: SecurityException) {
                // Izin belum lengkap untuk UID tertentu (system app, dll), lewati saja
                continue
            } catch (e: Exception) {
                continue
            }
        }

        return Pair(totalBytes, results.sortedByDescending { it.appBytes + it.dataBytes })
    }
}
